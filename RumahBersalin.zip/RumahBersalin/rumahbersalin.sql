-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2022 at 07:58 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rumahbersalin`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` varchar(6) NOT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `user_id` varchar(10) DEFAULT NULL,
  `password` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama`, `user_id`, `password`) VALUES
('A-0001', 'esa unggul', 'esa', 'unggul'),
('000001', 'admin', 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `bidan`
--

CREATE TABLE `bidan` (
  `nip` varchar(8) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(30) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `alamat` varchar(60) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `no_telp` varchar(14) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bidan`
--

INSERT INTO `bidan` (`nip`, `nama`, `alamat`, `no_telp`) VALUES
('P-0001', 'via', 'jl. jonggol', '0812345678'),
('P-0002', 'hestin', 'jl. kapan kapan', '0887654321');

-- --------------------------------------------------------

--
-- Table structure for table `daftar`
--

CREATE TABLE `daftar` (
  `no_daftar` varchar(6) NOT NULL,
  `tanggal` varchar(14) DEFAULT NULL,
  `jam` varchar(8) DEFAULT NULL,
  `no_rm` varchar(6) DEFAULT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `periksa` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `obat`
--

CREATE TABLE `obat` (
  `kode` varchar(6) NOT NULL,
  `nama_obat` varchar(30) DEFAULT NULL,
  `jenis` varchar(10) DEFAULT NULL,
  `satuan` varchar(10) DEFAULT NULL,
  `harga` varchar(8) DEFAULT NULL,
  `stok` varchar(6) DEFAULT NULL,
  `stokmin` varchar(3) DEFAULT NULL,
  `suplier` varchar(30) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `obat`
--

INSERT INTO `obat` (`kode`, `nama_obat`, `jenis`, `satuan`, `harga`, `stok`, `stokmin`, `suplier`) VALUES
('O-0001', 'amoxillin', 'Kapsul', 'strip', '9000', '8.0', '5', 'pt.kalbe farma'),
('O-0002', 'Rhinos Junior', 'Syrup', 'Botol', '55000', '7.0', '2', 'pt.rhinos farma'),
('O-0003', 'Rhinos Neo', 'Syrup', 'Botol', '30000', '40', '5', 'pt rhinos farma'),
('O-0004', 'termorex', 'Syrup', 'Botol', '25000', '100', '5', 'pt cikarang jaya'),
('O-0005', 'Tempra', 'Syrup', 'Botol', '30000', '2.0', '2', 'pt cikarang jaya'),
('O-0006', 'fc troches', 'Tablet', 'Strip', '10000', '50', '2', 'pt. meiji');

-- --------------------------------------------------------

--
-- Table structure for table `pasien`
--

CREATE TABLE `pasien` (
  `no_rm` varchar(6) NOT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `usia` varchar(8) DEFAULT NULL,
  `jenis_kel` varchar(10) DEFAULT NULL,
  `status` varchar(14) DEFAULT NULL,
  `pekerjaan` varchar(20) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `no_tlp` varchar(14) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `no_trans` varchar(6) NOT NULL,
  `no_per` varchar(6) NOT NULL,
  `tanggal` varchar(10) DEFAULT NULL,
  `jam` time DEFAULT NULL,
  `no_rm` varchar(6) DEFAULT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `kd_tin` varchar(6) DEFAULT NULL,
  `kode` varchar(6) DEFAULT NULL,
  `id` varchar(6) DEFAULT NULL,
  `tot_bayar` varchar(10) DEFAULT NULL,
  `bayar` varchar(10) DEFAULT NULL,
  `kembalian` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `periksa`
--

CREATE TABLE `periksa` (
  `no_per` varchar(6) NOT NULL,
  `no_daftar` varchar(6) DEFAULT NULL,
  `tanggal` varchar(14) DEFAULT NULL,
  `jam` varchar(8) DEFAULT NULL,
  `no_rm` varchar(6) DEFAULT NULL,
  `nama` varchar(30) DEFAULT NULL,
  `kd_tin` varchar(6) DEFAULT NULL,
  `ruang_bersalin` varchar(25) DEFAULT NULL,
  `harga_ruang` varchar(10) DEFAULT NULL,
  `keadaan_bayi` varchar(30) DEFAULT NULL,
  `jenkel_bayi` varchar(10) DEFAULT NULL,
  `nip` varchar(6) DEFAULT NULL,
  `diagnosa` varchar(30) DEFAULT NULL,
  `no_resep` varchar(6) DEFAULT NULL,
  `kode` varchar(10) DEFAULT NULL,
  `total_biaya` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `resep`
--

CREATE TABLE `resep` (
  `no_resep` varchar(6) NOT NULL,
  `tgl_resep` varchar(15) NOT NULL,
  `rincian_obat` varchar(60) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `resep`
--

INSERT INTO `resep` (`no_resep`, `tgl_resep`, `rincian_obat`) VALUES
('000001', '30/06/2013', 'amoxicillin, rhinos junior,'),
('000004', '28/07/2013', 'amoxcillin');

-- --------------------------------------------------------

--
-- Table structure for table `tindakan`
--

CREATE TABLE `tindakan` (
  `kd_tin` varchar(6) NOT NULL,
  `nama_tin` varchar(20) DEFAULT NULL,
  `harga` varchar(10) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tindakan`
--

INSERT INTO `tindakan` (`kd_tin`, `nama_tin`, `harga`) VALUES
('T-0001', 'suntik KB 1 bulan', '25000'),
('T-0002', 'Suntik KB 3 bulan', '30000'),
('T-0003', 'Imunisasi DPT', '65000'),
('T-0004', 'Imunisasi Polio', '15000'),
('T-0005', 'Imunisasi BCG', '30000'),
('T-0006', 'Periksa Kehamilan', '40000'),
('T-0007', 'Pengobatan Anak', '40000'),
('T-0008', 'Persalinan', '1200000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bidan`
--
ALTER TABLE `bidan`
  ADD PRIMARY KEY (`nip`);

--
-- Indexes for table `daftar`
--
ALTER TABLE `daftar`
  ADD PRIMARY KEY (`no_daftar`);

--
-- Indexes for table `obat`
--
ALTER TABLE `obat`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `pasien`
--
ALTER TABLE `pasien`
  ADD PRIMARY KEY (`no_rm`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`no_per`);

--
-- Indexes for table `periksa`
--
ALTER TABLE `periksa`
  ADD PRIMARY KEY (`no_per`);

--
-- Indexes for table `resep`
--
ALTER TABLE `resep`
  ADD PRIMARY KEY (`no_resep`);

--
-- Indexes for table `tindakan`
--
ALTER TABLE `tindakan`
  ADD PRIMARY KEY (`kd_tin`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
